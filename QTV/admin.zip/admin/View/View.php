<?php
class View
{
}
?>